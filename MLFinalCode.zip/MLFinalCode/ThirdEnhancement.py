#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 24 11:09:44 2019

@author: akm
"""

import os
import re
import io
import requests
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from zipfile import ZipFile
from tensorflow.python.framework import ops

ops.reset_default_graph()

# Start a graph
session = tf.Session()

# Set RNN parameters
#epochsVal = 75
epochsVal = 75
batch_sizeVal = 500
max_sequence_lengthVal = 25
rnn_sizeVal = 10
embedding_sizeVal = 50
min_word_frequencyVal = 10
learning_rateVal = 1
dropout_keep_probVal = tf.placeholder(tf.float32)

# Download or open data
data_directory = 'temp'
data_file = 'text_data.txt'

# The Code initially checks for the directory struture in the OS level, ignores if already present, creates a new directory if not present.
if not os.path.exists(data_directory):
    os.makedirs(data_directory)

# The Code now checks for the file present in the location for reading purpose
if not os.path.isfile(os.path.join(data_directory, data_file)):
    fp = open('/Users/akm/PycharmProjects/MLPart1/SMSSpamCollection_tensorflow', 'r')
    files = fp.read()
    # Format Data
#    text_data = files.decode()
    text_data_formatted = files.decode()
    text_data_formatted = text_data_formatted.encode('ascii', errors='ignore')
    text_data_formatted = text_data_formatted.decode().split('\n')

    # Save data to text file
    with open(os.path.join(data_directory, data_file), 'w') as file_connection:
        for text_value in text_data_formatted:
            file_connection.write("{}\n".format(text_value))
else:
    # Open data from text file
    text_data_formatted = []
    cnt=0
    with open(os.path.join(data_directory, data_file), 'r') as file_connection:
        for rows in file_connection:
            #cnt = cnt + 1
            text_data_formatted.append(rows)
    text_data_formatted = text_data_formatted[:-1]
    #print(cnt)

text_data_formatted = [x.split('\t') for x in text_data_formatted if len(x) >= 1]
[text_data_target, text_data_train] = [list(x) for x in zip(*text_data_formatted)]


# Create a text cleaning function
def clean_text(text_string_formatted):
    text_string_formatted = re.sub(r'([^\s\w]|_|[0-9])+', '', text_string_formatted)
    text_string_formatted = " ".join(text_string_formatted.split())
    text_string_formatted = text_string_formatted.lower()
    return text_string_formatted


# Clean texts
text_data_train = [clean_text(x) for x in text_data_train]

# Change texts into numeric vectors
vocabulary_processor = tf.contrib.learn.preprocessing.VocabularyProcessor(max_sequence_lengthVal,
                                                                     min_frequency=min_word_frequencyVal)
text_processed = np.array(list(vocabulary_processor.fit_transform(text_data_train)))

# Shuffle and split data
text_processed = np.array(text_processed)
text_data_target = np.array([1 if x == 'ham' else 0 for x in text_data_target])
shuffled_ix = np.random.permutation(np.arange(len(text_data_target)))
x_shuffled = text_processed[shuffled_ix]
y_shuffled = text_data_target[shuffled_ix]

# Split train/test set
ix_cutoff = int(len(y_shuffled) * 0.75)
x_train, x_test = x_shuffled[:ix_cutoff], x_shuffled[ix_cutoff:]
y_train, y_test = y_shuffled[:ix_cutoff], y_shuffled[ix_cutoff:]
vocabulary_size = len(vocabulary_processor.vocabulary_)
print("Vocabulary Size: {:d}".format(vocabulary_size))
print("75-25 Train Test split: {:d} -- {:d}".format(len(y_train), len(y_test)))

# Create placeholders
xaxis_data = tf.placeholder(tf.int32, [None, max_sequence_lengthVal])
yaxis_output = tf.placeholder(tf.int32, [None])

# Create embedding
embedding_mat_size = tf.Variable(tf.random_uniform([vocabulary_size, embedding_sizeVal], -1.0, 1.0))
embedding_output_var = tf.nn.embedding_lookup(embedding_mat_size, xaxis_data)

# Define the RNN cell
# tensorflow change >= 1.0, rnn is put into tensorflow.contrib directory. Prior version not test.
if tf.__version__[0] >= '1':
    cellVal = tf.contrib.rnn.BasicRNNCell(num_units=rnn_sizeVal)
else:
    cellVal = tf.nn.rnn_cell.BasicRNNCell(num_units=rnn_sizeVal)

outputVal, state = tf.nn.dynamic_rnn(cellVal, embedding_output_var, dtype=tf.float32)
outputVal = tf.nn.dropout(outputVal, dropout_keep_probVal)

# Get output of RNN sequence
outputVal = tf.transpose(outputVal, [1, 0, 2])
lastVal = tf.gather(outputVal, int(outputVal.get_shape()[0]) - 1)

weightVal = tf.Variable(tf.truncated_normal([rnn_sizeVal, 2], stddev=0.1))
biasVal = tf.Variable(tf.constant(0.1, shape=[2]))
logits_out = tf.matmul(lastVal, weightVal) + biasVal

# Loss function
lossesVal = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=logits_out, labels=yaxis_output)
lossVal = tf.reduce_mean(lossesVal)

accuracy = tf.reduce_mean(tf.cast(tf.equal(tf.argmax(logits_out, 1), tf.cast(yaxis_output, tf.int64)), tf.float32))

optimizer = tf.train.RMSPropOptimizer(learning_rateVal)
train_step = optimizer.minimize(lossVal)

init = tf.global_variables_initializer()
session.run(init)

train_lossVal = []
test_lossVal = []
train_accuracyVal = []
test_accuracyVal = []
# Start training
for epochVal in range(epochsVal):

    # Shuffle training data
    shuffled_ix = np.random.permutation(np.arange(len(x_train)))
    x_train = x_train[shuffled_ix]
    y_train = y_train[shuffled_ix]
    num_batchesVal = int(len(x_train) / batch_sizeVal) + 1
    # TO DO CALCULATE GENERATIONS ExACTLY
    for i in range(num_batchesVal):
        # Select train data
        min_ix = i * batch_sizeVal
        max_ix = np.min([len(x_train), ((i + 1) * batch_sizeVal)])
        x_train_batch = x_train[min_ix:max_ix]
        y_train_batch = y_train[min_ix:max_ix]

        # Run train step
        train_dictVal = {xaxis_data: x_train_batch, yaxis_output: y_train_batch, dropout_keep_probVal: 0.5}
        session.run(train_step, feed_dict=train_dictVal)

    # Run loss and accuracy for training
    temp_train_loss, temp_train_acc = session.run([lossVal, accuracy], feed_dict=train_dictVal)
    train_lossVal.append(temp_train_loss)
    train_accuracyVal.append(temp_train_acc)
    #print('Epoch: {}, Train Loss: {:.2}, Train Acc: {:.2}'.format(epochVal + 1, temp_train_loss, temp_train_acc))


    # Run Eval Step
    test_dict = {xaxis_data: x_test, yaxis_output: y_test, dropout_keep_probVal: 1.0}
    temp_test_loss, temp_test_acc = session.run([lossVal, accuracy], feed_dict=test_dict)
    test_lossVal.append(temp_test_loss)
    test_accuracyVal.append(temp_test_acc)
    print('Epoch: {}, Test Loss: {:.2}, Test Acc: {:.2}'.format(epochVal + 1, temp_test_loss, temp_test_acc))

# Plot loss over time
epoch_seqVal = np.arange(1, epochsVal + 1)
plt.plot(epoch_seqVal, train_lossVal, 'k--', label='Train Set')
plt.plot(epoch_seqVal, test_lossVal, 'r-', label='Test Set')
plt.title('Softmax Loss')
plt.xlabel('Epochs')
plt.ylabel('Softmax Loss')
plt.legend(loc='upper left')
plt.show()

# Plot accuracy over time
plt.plot(epoch_seqVal, train_accuracyVal, 'k--', label='Train Set')
plt.plot(epoch_seqVal, test_accuracyVal, 'r-', label='Test Set')
plt.title('Test Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend(loc='upper left')
plt.show()