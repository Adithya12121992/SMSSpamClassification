import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory
# -*- coding: utf-8 -*-
# Importing the dataset
dataset1 = pd.read_csv('spam.csv' , encoding='cp437')

y=dataset1.iloc[:,0].values
import re
import nltk
#nltk.download('stopwords')
from nltk.stem.porter import PorterStemmer
from nltk.corpus import stopwords
orpus=[]
for i in range(0,5786):
    review = re.sub('[^a-zA-Z]',' ',dataset1['v2'][i])
    review=review.lower()
    review=review.split()
    ps=PorterStemmer()
    review=[ps.stem(word) for word in review if not word in set(stopwords.words('english'))]
    review=' '.join(review)
    orpus.append(review)
from sklearn.feature_extraction.text import CountVectorizer    
cv=CountVectorizer(max_features=3000)
x=cv.fit_transform(orpus).toarray()
from sklearn.preprocessing import LabelEncoder
le=LabelEncoder()
y=le.fit_transform(y)   

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size = 0.20)
print("########  RANDOM FOREST ##############")
from sklearn.ensemble import RandomForestClassifier
classifier1=RandomForestClassifier(n_estimators=15,criterion='entropy')
classifier1.fit(X_train,y_train)
predRF=classifier1.predict(X_test)
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score
print('Accuracy score: {}'.format(accuracy_score(y_test, predRF)))
print('Precision score: {}'.format(precision_score(y_test, predRF)))
print('Recall score: {}'.format(recall_score(y_test, predRF)))
print('F1 score: {}'.format(f1_score(y_test, predRF)))


# Any results you write to the current directory are saved as output.
print("########## KNN ##########")
from sklearn.neighbors import KNeighborsClassifier
classifier2 = KNeighborsClassifier(n_neighbors=3)
classifier2.fit(X_train,y_train)
predKNN=classifier2.predict(X_test)
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score
print('Accuracy score: {}'.format(accuracy_score(y_test, predKNN)))
print('Precision score: {}'.format(precision_score(y_test, predKNN)))
print('Recall score: {}'.format(recall_score(y_test, predKNN)))
print('F1 score: {}'.format(f1_score(y_test, predKNN)))

print("######### ENSEMBLE BAGGING #########")
from sklearn.ensemble import BaggingClassifier
classifier3 = BaggingClassifier(base_estimator=None, n_estimators=10, max_samples=1.0, max_features=1.0, bootstrap=True, bootstrap_features=False, oob_score=False, warm_start=False, n_jobs=None, random_state=None, verbose=0)
classifier3.fit(X_train,y_train)
PredBag=classifier3.predict(X_test)
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score
print('Accuracy score: {}'.format(accuracy_score(y_test, PredBag)))
print('Precision score: {}'.format(precision_score(y_test, PredBag)))
print('Recall score: {}'.format(recall_score(y_test, PredBag)))
print('F1 score: {}'.format(f1_score(y_test, PredBag)))
'''
print("######### KMEANS BAGGING #########")
from sklearn.cluster import KMeans
classifier4 = KMeans(n_clusters=8, init='k-means++', n_init=10, max_iter=300, tol=0.0001, precompute_distances='auto', verbose=0, random_state=None, copy_x=True, n_jobs=None, algorithm='auto')
classifier4.fit(X_train,y_train)
PredKM=classifier4.predict(X_test)
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score
print('Accuracy score: {}'.format(accuracy_score(y_test, PredKM)))
print('Precision score: {}'.format(precision_score(y_test, PredKM, average='micro')))
print('Recall score: {}'.format(recall_score(y_test, PredKM,average='micro')))
print('F1 score: {}'.format(f1_score(y_test, PredKM,average='micro')))

from sklearn.model_selection import cross_val_score
from sklearn import metrics 
import pandas as pd 
import matplotlib.pyplot as plt 

ns_probs = PredBag
lr_probs = predKNN
an_probs = predRF
#lr_probs = lr_probs[:, 1]
ns_auc = roc_auc_score(y_test, ns_probs)
lr_auc = roc_auc_score(y_test, lr_probs)
an_auc = roc_auc_score(y_test,an_probs)
ns_fpr, ns_tpr, _ = roc_curve(y_test, ns_probs)
lr_fpr, lr_tpr, _ = roc_curve(y_test, lr_probs)
an_fpr, an_tpr, _ = roc_curve(y_test, an_probs)
pyplot.plot(ns_fpr, ns_tpr, linestyle='--', label='ENSEMBLE BAGGING')
pyplot.plot(lr_fpr, lr_tpr, marker='.', label='KNN')
pyplot.plot(an_fpr, an_tpr, marker='.', label='RANDOM FOREST')
pyplot.xlabel('False Positive Rate')
pyplot.ylabel('True Positive Rate')
pyplot.legend()
pyplot.show()
'''