import numpy as np
import pandas as pd
import csv
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB, BernoulliNB
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report
import seaborn as sns
from sklearn.neighbors import KNeighborsClassifier
from sklearn import tree
from sklearn import svm
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import KFold
import scipy
from scipy.sparse import csr_matrix, hstack
import warnings
warnings.filterwarnings("ignore")
messagesVal = pd.read_csv('spam.csv',skiprows=1, names=["class", "text", "r1", "r2", 'r3'], encoding='latin-1')
del messagesVal['r1']
del messagesVal['r2']
del messagesVal['r3']

#Add a length column
messagesVal['length'] = messagesVal['text'].map(lambda text: len(text))
messagesVal.head()

print("Mean of ham length: "+str(np.mean(messagesVal[messagesVal['class']=='ham']['length'])))
print("Mean of spam length: "+str(np.mean(messagesVal[messagesVal['class']=='spam']['length'])))


pallete1 = sns.color_palette()
# Read in data
dfVal = pd.read_csv('spam.csv', encoding='latin-1')
dfVal = dfVal.drop(["Unnamed: 2", "Unnamed: 3", "Unnamed: 4"], axis=1)
dfVal = dfVal.rename(columns={"v1":"label", "v2":"sms_text"})
# Character count
msgs1 = pd.Series(dfVal['sms_text'].tolist())
ham_messagesList = pd.Series(dfVal[dfVal['label'] == 'ham']['sms_text'].tolist())
spam_messagesList = pd.Series(dfVal[dfVal['label'] == 'spam']['sms_text'].tolist())
# Create the corresponding distribution of character counts for each list.
# We count the number of characters in each message using the `len` function.
dist_all = msgs1.apply(len)
dist_ham = ham_messagesList.apply(len)
dist_spam = spam_messagesList.apply(len)
# Plot distribution of character count of all messages
plt.figure(figsize=(12, 8))
plt.hist(dist_all, bins=100, range=[0,400], color=pallete1[3], density=True, label='All')
plt.title('Normalised histogram of word count in all messages', fontsize=15)
plt.legend()
plt.xlabel('Number of Words', fontsize=15)
plt.ylabel('Probability', fontsize=15)

print('# Summary statistics for word count of all messages')
print('mean-all {:.2f} \nstd-all {:.2f} \nmin-all {:.2f} \nmax-all {:.2f}'.format(dist_all.mean(), 
                          dist_all.std(), dist_all.min(), dist_all.max()))
# Plot distributions of character counts for spam vs ham messages
plt.figure(figsize=(12,8))
plt.hist(dist_ham, bins=100, range=[0,250], color=pallete1[1], density=True, label='ham')
plt.hist(dist_spam, bins=100, range=[0, 250], color=pallete1[2], density=True, alpha=0.5, label='spam')
plt.title('Normalised histogram of word count in messages', fontsize=15)
plt.legend()
plt.xlabel('Number of Words', fontsize=15)
plt.ylabel('Probability', fontsize=15)
print('# Summary statistics for word count of ham vs spam messages')
print('mean-ham  {:.2f}   mean-spam {:.2f} \nstd-ham   {:.2f}   std-spam   {:.2f} \nmin-ham    {:.2f}   min-ham    {:.2f} \nmax-ham  {:.2f}   max-spam  {:.2f}'.format(dist_ham.mean(), 
                         dist_spam.mean(), dist_ham.std(), dist_spam.std(), dist_ham.min(), dist_spam.min(), dist_ham.max(), dist_spam.max()))


X_train,X_test,y_train,y_test = train_test_split(messagesVal["text"],messagesVal["class"], test_size = 0.1, random_state = 10)
vectVal = CountVectorizer(analyzer='word', ngram_range=(1, 3),stop_words='english') #uses 1 - 3 word length grams
vectVal.fit(X_train)
X_train_df = vectVal.transform(X_train)
X_test_df = vectVal.transform(X_test)
prediction = dict()

# function definition
def hyperparameter_qual(modelClaasifier, model_plot, param, param_plot, paramsVal, scale):
    test_sizes = test_sizes = np.linspace(.1,.9,9)
    # init grabbing accs
    acc_param1 = []
    # get vectorizer
    vectVal = CountVectorizer(analyzer='word', stop_words='english')
    max_accVal = 0
    max_test_sizeVal = 0
    max_paramVal = 0
    for j in test_sizes:
        # get datasets
        X_train,X_test,y_train,y_test = train_test_split(
            messagesVal["text"],messagesVal["class"], test_size = j, random_state = 10)
        # vectorize
        vectVal.fit(X_train)
        X_train_df = vectVal.transform(X_train)
        X_test_df = vectVal.transform(X_test)
        loc_y = []
        for i in paramsVal:
            modelClaasifier = modelClaasifier.set_params(**{param: i})
            modelClaasifier.fit(X_train_df, y_train)
            prediction = modelClaasifier.predict(X_test_df)
            acc = accuracy_score(y_test, prediction)
            if max_accVal < acc:
                max_accVal = acc
                max_test_sizeVal = j
                max_paramVal = i
            loc_y.append(acc)
        acc_param1.append(loc_y)
        
    # Plotting code
    plt.title(model_plot + ' Accuracy Score vs ' + param_plot)
    plt.ylabel('Accuracy Score')
    plt.xlabel(param_plot)
    plt.xscale(scale)
    for i in range(len(acc_param1)):
        plt.plot(paramsVal, acc_param1[i])
    tests = [int(len(messagesVal['class']) * size) for size in test_sizes]
    plt.legend(test_sizes, title='Test Set Proportion')
    plt.show()
    
    print('Max Accuracy:', max_accVal)
    print('Max Test Proportion:', max_test_sizeVal)
    print('Max', param_plot + ':', max_paramVal)

def create_confuse(model_nameVal, confuseVal, extra_titleVal):
    confuseVal = confuseVal.astype('float') / confuseVal.sum(axis=1)[:, np.newaxis]
    plt.imshow(confuseVal, cmap=plt.cm.Blues, interpolation='nearest')
    plt.title(model_nameVal + ' Normalized Confusion Matrix ' + extra_titleVal)
    plt.colorbar()
    plt.grid('off')
    plt.ylabel('Expected Label')
    plt.xlabel('Predicted Label')
    tick_marks = ['ham', 'spam']
    plt.xticks([0, 1], tick_marks)
    plt.yticks([0, 1], tick_marks)
    plt.show()

def plot_confuse(modelClaasifier, X_train_df, y_train, X_test_df, y_test, model_nameVal, extra_titleVal):
    modelClaasifier.fit(X_train_df, y_train)
    prediction = modelClaasifier.predict(X_test_df)
    confuseVal = confusion_matrix(y_test, prediction)
    create_confuse(model_nameVal, confuseVal, extra_titleVal)
    
    
###############################################################################
# KNN Classifiers now 
paramsVal = range(1,41)
# Neighbors plot
hyperparameter_qual(KNeighborsClassifier(), 'K Nearest Neighbor', 'n_neighbors', '# of Neighbors', paramsVal, 'linear')
plot_confuse(KNeighborsClassifier(n_neighbors=1), X_train_df, y_train, X_test_df, y_test, 'KNN', '$n = 1$')

'''
# Naive Bayes
# Multinomial
print("################   MULTINOMIAL NAIVE BAYES   #####################")
paramsVal = [0.001,0.1,0.3,0.5,0.7,1,3]
hyperparameter_qual(MultinomialNB(), 'Multinomial Naive Bayes', 'alpha', 'Additive smooting parameter', paramsVal, 'linear')
modelClaasifier = MultinomialNB(alpha=0.7)
modelClaasifier.fit(X_train_df,y_train)
prediction["MultinomialNB"] = modelClaasifier.predict(X_test_df)
print ("accuracy: "+str(accuracy_score(y_test,prediction["MultinomialNB"])))
plot_confuse(MultinomialNB(), X_train_df, y_train, X_test_df, y_test, 'Multinomial NB', '')

print("################   BERNOULI'S NAIVE BAYES   #####################")
#Bernouli's NB
modelClaasifier = BernoulliNB()
modelClaasifier.fit(X_train_df,y_train)
prediction["BernoulliNB"] = modelClaasifier.predict(X_test_df)
print ("accuracy: "+str(accuracy_score(y_test,prediction["BernoulliNB"])))
plot_confuse(BernoulliNB(), X_train_df, y_train, X_test_df, y_test, 'Bernoulli NB', '')

print("################   DECISION TREES   #####################")
#Decision Trees
dtc = tree.DecisionTreeClassifier()
paramsVal = np.logspace(-7, 2, num=8)
hyperparameter_qual(dtc, 'Decision Trees', 'min_impurity_decrease', 'Min Impurity Split', paramsVal, 'log')
paramsVal = range(1,11)
hyperparameter_qual(tree.DecisionTreeClassifier(), 'Decision Trees', 'max_depth', 'Max Tree Depth', paramsVal, 'linear')
plot_confuse(tree.DecisionTreeClassifier(), X_train_df, y_train, X_test_df, y_test, 'Decision Trees', '')
'''


print("################   RANDOM FOREST  #####################")
#Decision Trees
from sklearn.ensemble import RandomForestClassifier
rff = RandomForestClassifier(n_estimators=15,criterion='entropy')
paramsVal = np.logspace(-7,2,num=10)
hyperparameter_qual(rff, 'Random forest', 'min_impurity_decrease', 'Min Impurity Split', paramsVal, 'log')
paramsVal = range(1,11)
hyperparameter_qual(tree.DecisionTreeClassifier(), 'Random forest', 'max_depth', 'Max Tree Depth', paramsVal, 'linear')
plot_confuse(RandomForestClassifier(), X_train_df, y_train, X_test_df, y_test, 'Random forest', '')


print("################   LOGISTIC REGRESSION   #####################")
#Logistic regression
paramsVal = np.logspace(-5, 4, num=10)
hyperparameter_qual(LogisticRegression(solver='lbfgs'), 'Logistic Regression', 'C', 'Inverse Regularizer', paramsVal, 'log')
paramsVal = np.logspace(-2, 2, num=5)
hyperparameter_qual(LogisticRegression(solver='lbfgs'), 'Logistic Regression', 'tol', 'Tolerance for Stopping', paramsVal, 'log')
modelClaasifier = LogisticRegression(C=1000, tol=0.01)
modelClaasifier.fit(X_train_df,y_train)
prediction["Logistic"] = modelClaasifier.predict(X_test_df)
accuracy_score(y_test,prediction["Logistic"])
confmat = confusion_matrix(y_test, prediction["Logistic"])
confmat = confmat.astype('float') / confmat.sum(axis=1)[:, np.newaxis]
plt.imshow(confmat, cmap=plt.cm.Blues, interpolation='nearest')
plt.title('Normalized Logistic Regression Confusion Matrix')
plt.colorbar()
plt.grid('off')
plt.ylabel('Expected Label')
plt.xlabel('Predicted Label')
tick_marks = ['ham', 'spam']
plt.xticks([0, 1], tick_marks)
plt.yticks([0, 1], tick_marks)
plt.show()

# SVM
print("################   SUPPORT VECTOR MACHINES   #####################")
paramsVal = np.logspace(-2, 5, num=8)
hyperparameter_qual(svm.SVC(gamma='scale'), 'SVM', 'C', 'Regularization', paramsVal, 'log')
modelClaasifier = svm.SVC(C=10000,gamma='scale')
modelClaasifier.fit(X_train_df, y_train)
prediction['SVM'] = modelClaasifier.predict(X_test_df)
accuracy_score(y_test, prediction['SVM'])
confmat = confusion_matrix(y_test, prediction["SVM"])
confmat = confmat.astype('float') / confmat.sum(axis=1)[:, np.newaxis]
plt.imshow(confmat, cmap=plt.cm.Blues, interpolation='nearest')
plt.title('SVM Confusion Matrix')
plt.colorbar()
plt.grid('off')
plt.ylabel('Expected Label')
plt.xlabel('Predicted Label')
tick_marks = ['ham', 'spam']
plt.xticks([0, 1], tick_marks)
plt.yticks([0, 1], tick_marks)
plt.show()

print("################   ENSEMBLE BAGGING  #####################")
#Decision Trees
from sklearn.ensemble import BaggingClassifier
bgg = BaggingClassifier(base_estimator=None, n_estimators=10, max_samples=1.0, max_features=1.0, bootstrap=True, bootstrap_features=False, oob_score=False, warm_start=False, n_jobs=None, random_state=None, verbose=0)
plot_confuse(RandomForestClassifier(), X_train_df, y_train, X_test_df, y_test, 'Ensemble bagging', '')

# KFOLD CROSS VALIDATION
print("#################  K FOLD CROSS VALIDATION #########################")
def crossValidate(modelClaasifier, prediction, modelName, messagesVal, splits):
    vectVal = CountVectorizer(analyzer='word', ngram_range=(1, 3),stop_words='english') #uses 1 - 3 word length grams
    #K fold validation
    kf = KFold(n_splits=splits)

    i = 0
    #loop through cross validated input
    for train_index, test_index in kf.split(messagesVal["text"], messagesVal["class"]):
        i = i + 1

        X_train, X_test = messagesVal["text"][train_index], messagesVal["text"][test_index]
        Y_train, Y_test = messagesVal["class"][train_index], messagesVal["class"][test_index]
        length_train, length_test = messagesVal["length"][train_index].as_matrix()[:,np.newaxis], messagesVal["length"][test_index].as_matrix()[:,np.newaxis]
        length_train, length_test = scipy.sparse.coo_matrix(length_train), scipy.sparse.coo_matrix(length_test)
    
        vectVal.fit(X_train)
        
        #add length feature to the feature vector
        X_train_df = hstack([vectVal.transform(X_train), length_train])
        X_test_df = hstack([vectVal.transform(X_test), length_test])
        modelClaasifier.fit(X_train_df, Y_train)
        if (i%10 == 0):
            print( "Iteration "+str(i)+": "+str(accuracy_score(Y_test, modelClaasifier.predict(X_test_df))))

    #really simple to create a model and train it.
    h = scipy.sparse.coo_matrix(messagesVal['length'].as_matrix()[:,np.newaxis])
    X_df = hstack([vectVal.transform(messagesVal["text"]), h])
    prediction[modelName] = modelClaasifier.predict(X_df)

    #print out the accuracy score over all the messages, because we've k cross validated
    print(accuracy_score(messagesVal["class"], prediction[modelName]))
    create_confuse(modelName, confusion_matrix(messagesVal["class"], prediction[modelName]), "")
    
modelClaasifier = MultinomialNB()
crossValidate(modelClaasifier, prediction, "Multnomial NB with 300 fold cross validation", messagesVal, 300)